#ifndef _MY_MATH_H_
#define _MY_MATH_H_

const float PI = 3.14159265358979;
const float INV_PI = 0.3183098861838;

#endif